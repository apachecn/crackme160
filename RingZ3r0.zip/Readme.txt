My first crackme , well i hope you found it funny...

As you can read in the info in the progz you cant :

use disassembler and patch the programm.

You must :

found the right key to register proggy by pressing the register button.

To do this you can use debugger like Sice.



Btw  : Pay attention on some JOKE! ;)


