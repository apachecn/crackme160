Dear reader!

I wrote this little example of protectionism in order to show how some
confusing and due to its algorithms tough targets may function. Please
feel free to analyse it in any way you regard as appropriate, because
commercial protectionism is too dangerous a concept to be toyed with
due to software slowly becoming uncrackable.

By the way, I regard my crackme only then as cracked, when you:
a) modify the compare routine to give correct results
b) generate a couple of valid matrix codes
c) write a matrix code generator
d) modify the crackme to force it being registered when it is launched.

If you have successfully completed any of the points above, you may ask
me for Delphi source code of "MatrixxxMadness 1".

Although my algorithms are not that easy to locate, to disable and to 
rip in order to write a code generator, my crackme is in so far fair,
that I have not implemented any disassembly preventive code, debugging
and dumping counter-measures.

As a small help I include a valid matrix code. 1 means check box is
checked, 0 means check box is unchecked.

Name: The AntiXryst

1 0 0 1 0 1 1 1
1 0 1 1 0 1 1 0
0 1 0 1 0 0 0 1
1 0 0 0 0 0 0 1
1 1 1 1 0 1 0 0
1 0 1 1 0 0 0 1
1 1 0 0 0 1 0 1
0 1 1 0 1 0 1 0


Now it's up to you to pluck the quills from the porcupine. The next
time, you wont be let with just one porcupine...


Sincerely yours,

	The AntiXryst [CrossOver]
----------------------------------------------------------------------

Please visit our site: http://crossover.tsx.org