   ____                     __       __
  /  _/_ _  __ _  ___  ____/ /____ _/ /
 _/ //  ' \/  ' \/ _ \/ __/ __/ _ `/ / 
/___/_/_/_/_/_/_/\___/_/  \__/\_,_/_/                                      
   ____                          __          __     
  / __ \___ ___ _______ ___  ___/ /__ ____  / /____ 
 / /_/ / -_|_-</ __/ -_) _ \/ _  / _ `/ _ \/ __(_-< 
/_____/\__/___/\__/\__/_//_/\_,_/\_,_/_//_/\__/___/ 

        http://www.ImmortalDescendants.com

******************************************************
*  File: Immortal Descendants CrackMe v3.0           *
*  Author: Volatility (volatility@prodigy.net)       *
*  Type: CrackMe                                     *
*  Protection(s): User Name/Serial Number/Key File   *
*  Crack Difficulty: Intermediate                    *
******************************************************

INTRODUCTION

Greetings, and thanks for trying out my crackme.  This
one should be a bit tougher to bust than my previous
ones.

ABOUT THE PROTECTION

The main protection is a missing key file, which you
can either reconstruct, or you can figure out the 
calculation to produce a valid one.

The Register button is disabled until your valid
serial number is entered.

Anti-Soft Ice and Smartcheck (thanks to Eternal Bliss) 
coding has been added to make things a bit tougher for 
you as well :)


OBJECTIVES

First and foremost, to produce a valid key file.  After
this is finished, figure out the calculation, and 
write a keyfile generator!

FINAL WORDS

If you do successfully crack this program, PLEASE send
me an e-mail at volatility@prodigy.net telling me EXACTLY
how you did it.

If you write an essay or keyfile generator, PLEASE send 
that to me as well, and I'll post it with the other 
solutions on our website.

If you need help or hints, you may e-mail me.  I
won't give you the full crack, but I may be able to give
you some more hints to get you started again.

GREETINGS

Big shout-outs to: Eternal Bliss, Jeff, Lord Soth, 
NiKai, The Sandman, Torn@do, vladimir, _ytc

Again, thanks for trying your hands at my program, and 
happy cracking!

-Volatility-