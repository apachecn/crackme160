YoYo Dwed..

This are my first crackme that are written in Win 32 Assembler (MASM)

I hace quitted Hellforge, The Cracking Answer and The Norwegioan Underground E-Zine Yesterday only for learning Win 32 Assembler and it are a good choice for mee. Since my tutorials sux too much atm. and I'm are not good in cracking so i will instead learn Codin, and the best part, it are in Win 32 Assembler :)

So, U will only need one "Bpx MessageBoxa" on this little crackme.. It suc alot but it are still mine so don't mess it up please.. Try tu use so many tools as you can and learn to crack in new ways, that are the coolest thing to do...

But now, it are time to work on a GFX to my girlfriend, cya dweds...

Greeting's goes to: LaZaRuS, Mercution, Dark wolf, Falcon, Eternal-Bliss, Birna Janes, MagicRalph, EP-180, ^AlX^, Cobb, Potsmoke, Acidfusion, Marton, Andd all who have helped me directly or indirectly....

U can fun this crackme from AcidCool.cjb.net and Crackmes.cjb.net

Acid_Cool_178 Design Company For crackers And Coder's.. :) (LOL)
Acid_Cool_178@hotmail.com